import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:pic_2_plate_ai/domain/cubit/meal/meal_cubit.dart';
import 'package:pic_2_plate_ai/ui/pages/meal_creation/widgets/form_meal_creation.dart';
import 'package:pic_2_plate_ai/ui/pages/meal_creation/widgets/loading_meal_widget.dart';
import 'package:image_picker/image_picker.dart';

class MealCreationPage extends StatelessWidget {
  const MealCreationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: BlocBuilder<MealCubit, MealState>( 
        builder: (context, state) => Text(
          switch (state) {
            MealSettingsParameters() => 'Edit your receipt',
            MealLoading() => '',
            MealLoaded() => 'Your meal is ready',
            ErrorState() => 'Customize your receipt',
          },
          style: Theme.of(context).textTheme.titleLarge,
        ),
      )),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: BlocBuilder<MealCubit, MealState>( 
            builder: (context, state) => AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: switch (state) {
                MealSettingsParameters() => FormMealCreation(state: state),
                MealLoading() => const Center(child: LoadingMealWidget()),
                MealLoaded() => Markdown(data: state.meals.first),
                ErrorState() => Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Something went wrong',
                        style: Theme.of(context).textTheme.displayMedium,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        state.error.toString(),
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => context.read<MealCubit>().load(),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).colorScheme.primary,
                        ),
                        child: Text(
                          "Try again",
                          style: Theme.of(context).textTheme.labelLarge,
                        ),
                      ),
                    ],
                  ),
              },
            ),
          ),
        ),
      ),
      floatingActionButton: BlocBuilder<MealCubit, MealState>( 
        builder: (context, state) => Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            // Retrigger Gamini AI button
            if (state is MealLoaded)
              FloatingActionButton(
                onPressed: () => context.read<MealCubit>().load(),
                tooltip: 'Retrigger AI',
                child: const Icon(Icons.restart_alt_rounded),
              ),
            
            const SizedBox(width: 16), // Space between buttons

            // Cooking Done button
            if (state is MealLoaded)
              FloatingActionButton(
                onPressed: () {
                  // Navigate to the CookingDonePage
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => CookingDonePage()),
                  );
                },
                tooltip: 'Cooking Done',
                child: const Icon(Icons.check_circle_outline),
              ),
          ],
        ),
      ),
    );
  }
}

// New page for taking before and after pictures
class CookingDonePage extends StatefulWidget {
  const CookingDonePage({super.key});

  @override
  _CookingDonePageState createState() => _CookingDonePageState();
}

class _CookingDonePageState extends State<CookingDonePage> {
  final ImagePicker _picker = ImagePicker();
  List<XFile>? _images = [];  // List to store selected images

  Future<void> _pickImages() async {
    final pickedFiles = await _picker.pickMultiImage();
    if (pickedFiles != null) {
      setState(() {
        _images?.addAll(pickedFiles);  // Add selected images to the list
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Take Before and After Photos')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Please take a before and after photo of your meal.',
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _pickImages,
              child: const Text('Pick Images'),
            ),
            const SizedBox(height: 20),
            _images!.isNotEmpty
                ? Expanded(
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: _images!.length,
                      itemBuilder: (context, index) {
                        return Image.file(
                          File(_images![index].path),
                          fit: BoxFit.cover,
                        );
                      },
                    ),
                  )
                : const Text('No images selected yet.'),
          ],
        ),
      ),
    );
  }
}
