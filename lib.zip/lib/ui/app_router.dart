import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pic_2_plate_ai/data/repository/gemini_meal_repository.dart';
import 'package:pic_2_plate_ai/domain/cubit/meal/meal_cubit.dart';
import 'package:pic_2_plate_ai/ui/pages/meal_creation/meal_creation_page.dart';
import 'package:pic_2_plate_ai/ui/pages/onboarding/onboarding_page.dart';
import 'package:pic_2_plate_ai/ui/pages/meal_creation/share_my_achivement_page.dart';
import 'package:pic_2_plate_ai/ui/pages/meal_creation/what_is_in_my_food.dart';

abstract class RoutesNames {
  static const String onboarding = '/';
  static const String mealCreation = '/meal-creation';
  static const String shareMyAcchivement = '/share-my-achivement';
  static const String whatsInMyFood = '/what-is-in-my-food';
}

class AppRouter {
  static String getNestedRouteName() {
    return RoutesNames.onboarding;
  }

  final mealCubit = MealCubit(GeminiMealRepository());
  //final inMyFood = MealCubit(GeminiIngredientsRepository());

  Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RoutesNames.onboarding:
        return MaterialPageRoute(builder: (_) => const OnboardingPage());
      case RoutesNames.mealCreation:
        return MaterialPageRoute(
          builder: (_) => BlocProvider.value(value: mealCubit, child: const MealCreationPage()),
        );
      case RoutesNames.shareMyAcchivement:
        return MaterialPageRoute(
          builder: (_) => BlocProvider.value(value: mealCubit, child: const ShareMyAchivementPage()),
        );
      case RoutesNames.whatsInMyFood:
        return MaterialPageRoute(
          builder: (_) => BlocProvider.value(value: mealCubit, child: const WhatIsInMyFoodPage()),
        );  
      default:
        // Optionally provide a default route or a 404 page
        return MaterialPageRoute(builder: (_) => const Scaffold(body: Center(child: Text('Page not found'))));
    }
  }
}
